#include "../TouchRegionEngine.hpp"
#include <cassert>
#include <iostream>

int main() {
    using namespace ta;
    RegionConfig cfg;
    cfg.strokes = {{{10,10},{110,10},{110,110},{10,110},{10,10}}};
    cfg.mode = HitMode::Enclosed;
    MultitouchRegionTracker tracker(4);
    tracker.setRegion(cfg);

    auto ev=[](unsigned short type, unsigned short code, int value) {
        input_event e{}; e.type=type; e.code=code; e.value=value; return e;
    };
    // Finger 0 inside the enclosed region.
    tracker.consume(ev(EV_ABS, ABS_MT_SLOT, 0));
    tracker.consume(ev(EV_ABS, ABS_MT_TRACKING_ID, 42));
    tracker.consume(ev(EV_ABS, ABS_MT_POSITION_X, 60));
    tracker.consume(ev(EV_ABS, ABS_MT_POSITION_Y, 60));
    tracker.consume(ev(EV_SYN, SYN_REPORT, 0));
    assert(tracker.fingers()[0].active && tracker.fingers()[0].inRegion);

    // Finger 1 outside; finger 0 remains independently tracked.
    tracker.consume(ev(EV_ABS, ABS_MT_SLOT, 1));
    tracker.consume(ev(EV_ABS, ABS_MT_TRACKING_ID, 43));
    tracker.consume(ev(EV_ABS, ABS_MT_POSITION_X, 200));
    tracker.consume(ev(EV_ABS, ABS_MT_POSITION_Y, 200));
    tracker.consume(ev(EV_SYN, SYN_REPORT, 0));
    assert(tracker.fingers()[0].inRegion);
    assert(tracker.fingers()[1].active && !tracker.fingers()[1].inRegion);
    assert(tracker.anyFingerInRegion());

    // Releasing slot 0 must not release slot 1.
    tracker.consume(ev(EV_ABS, ABS_MT_SLOT, 0));
    tracker.consume(ev(EV_ABS, ABS_MT_TRACKING_ID, -1));
    tracker.consume(ev(EV_SYN, SYN_REPORT, 0));
    assert(!tracker.fingers()[0].active);
    assert(tracker.fingers()[1].active && !tracker.fingers()[1].inRegion);

    assert(scaleIntervalUs(1000, 2.f) == 500);
    assert(scaleIntervalUs(1000, 0.5f) == 2000);
    std::cout << "multitouch region engine tests passed\n";
}
