#!/system/bin/sh
set -eu
CXX=${CXX:-g++}
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=${TMPDIR:-/tmp}/touchassist-region-tests
mkdir -p "$OUT"
"$CXX" -std=c++17 -Wall -Wextra -Werror "$ROOT/tests/region_geometry_test.cpp" -o "$OUT/geometry"
"$CXX" -std=c++17 -Wall -Wextra -Werror "$ROOT/tests/multitouch_region_engine_test.cpp" -o "$OUT/multitouch"
"$CXX" -std=c++17 -Wall -Wextra -Werror "$ROOT/tests/region_runtime_test.cpp" -o "$OUT/runtime"
"$OUT/geometry"
"$OUT/multitouch"
"$OUT/runtime"
