#include "../RegionGeometry.hpp"
#include <cassert>
#include <iostream>
int main() {
    using namespace ta;
    const std::vector<Stroke> contour{{{10,10},{110,10},{110,110},{10,110},{10,10}}};
    assert(contains({60,10},contour,HitMode::Paths));
    assert(!contains({60,60},contour,HitMode::Paths));
    assert(contains({60,60},contour,HitMode::Enclosed));
    assert(contains({60,60},contour,HitMode::Both));
    assert(!contains({160,60},contour,HitMode::Enclosed));
    const std::vector<Stroke> openLines{{{10,10},{110,10}},{{110,110},{10,110}}};
    assert(!contains({60,60},openLines,HitMode::Enclosed)); // no phantom polygon between strokes
    assert(contains({60,10},openLines,HitMode::Paths));
    const auto moved=transform(contour,2.0f,2.0f,100.0f,50.0f);
    assert(contains({220,170},moved,HitMode::Enclosed));
    std::cout << "region geometry tests passed\n";
}
