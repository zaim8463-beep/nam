# TouchAssist native ARM64 bridge

The Android app's Gradle configuration builds `touchbridge.cpp` with the Android NDK for **arm64-v8a** and places the resulting executable in `app/build/generated/touchbridgeAssets/touchbridge`. The app copies that executable and the supervisor scripts into its private files directory and launches/stops the supervisor through `su`.

## Runtime flow

1. Selecting a saved region exports `files/region.conf`.
2. In floating-ball mode, the existing one-ball placement UI translates the whole saved region; confirming the ball exports the translated config and starts the bridge.
3. In no-ball mode, the unshifted config is exported and the bridge starts immediately.
4. A single tap on the main floating button closes the region overlay and stops the supervisor.
5. The supervisor watches the app PID and heartbeat. It only creates the `ready` marker after the native process has survived its startup check. The app checks that marker and the native PID before reporting success.
6. Service cleanup requests bridge shutdown. The native process releases `EVIOCGRAB` and destroys the uinput device on exit.

## Build requirements

- Android Studio / Gradle with Android Gradle Plugin 8.5.2
- Android SDK platform 34
- Android NDK and CMake 3.22.1 (installed through SDK Manager)
- JDK 17

Build a release APK from the project root:

```sh
gradle :app:assembleRelease (or Build > Generate Signed Bundle / APK in Android Studio)
```

The APK is ARM64-only, matching the target OPPO device. The NDK executable is generated during the build; it is intentionally not a host executable checked into the source tree.

## Important validation boundary

The host-side geometry/runtime tests validate parsing, region hit-testing and timing calculations only. This environment did not have Android SDK/NDK/Gradle, so no APK was built here and no test was run on the OPPO device. The bridge uses `EVIOCGRAB` and `/dev/uinput`; a failure in kernel permissions, SELinux policy, uinput setup, or Android InputReader compatibility can interrupt touch input until the bridge exits. Keep a hardware recovery path available and do not treat the package as device-validated.
