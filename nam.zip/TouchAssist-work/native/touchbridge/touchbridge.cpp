// Experimental Linux input bridge for Android rooted devices.
// Creates a virtual multitouch device, then exclusively grabs the physical device
// and forwards events unchanged. Closing this process releases EVIOCGRAB.
#include <linux/input.h>
#include <linux/uinput.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <poll.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <memory>
#include "RegionRuntime.hpp"

static volatile sig_atomic_t g_stop = 0;
static void on_signal(int) { g_stop = 1; }

static bool bit(const std::vector<unsigned long>& b, int n) {
    const int bits = sizeof(unsigned long) * 8;
    return n >= 0 && (size_t)(n / bits) < b.size() && (b[n / bits] & (1UL << (n % bits)));
}
static bool setbit(int fd, unsigned long req, int n) {
    return ioctl(fd, req, n) == 0 || errno == EINVAL;
}
static long long now_ms() {
    timespec t{}; clock_gettime(CLOCK_MONOTONIC, &t);
    return (long long)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}
static bool fresh(const char* path, int max_age_sec) {
    struct stat st{};
    if (stat(path, &st) != 0) return false;
    time_t age = time(nullptr) - st.st_mtime;
    return age >= -1 && age <= max_age_sec;
}
static void cleanup(int phys, int virt) {
    if (phys >= 0) ioctl(phys, EVIOCGRAB, 0);
    if (virt >= 0) { ioctl(virt, UI_DEV_DESTROY); close(virt); }
    if (phys >= 0) close(phys);
}

int main(int argc, char** argv) {
    if (argc != 4 && argc != 5) {
        fprintf(stderr, "usage: touchbridge <physical-event> <heartbeat-file> <watchdog-seconds> [region.conf]\n");
        return 2;
    }
    const char* dev = argv[1];
    const char* heartbeat = argv[2];
    int watchdog = atoi(argv[3]);
    if (watchdog < 3 || watchdog > 30) { fprintf(stderr, "watchdog must be 3..30 seconds\n"); return 2; }
    if (!fresh(heartbeat, watchdog)) { fprintf(stderr, "heartbeat missing/stale; refusing to grab input\n"); return 3; }

    ta::RuntimeConfig regionConfig{};
    bool regionEnabled = false;
    const char* regionConfigPath = argc == 5 ? argv[4] : nullptr;
    long long regionConfigMtime = 0;
    std::unique_ptr<ta::RegionRuntime> regionRuntime;
    if (argc == 5) {
        if (!ta::loadRuntimeConfig(argv[4], regionConfig)) {
            fprintf(stderr, "region config invalid/disabled; refusing to grab input\n"); return 3;
        }
        regionRuntime.reset(new ta::RegionRuntime(regionConfig));
        struct stat configStat{}; if (stat(regionConfigPath, &configStat) == 0)
            regionConfigMtime = static_cast<long long>(configStat.st_mtim.tv_sec) * 1000000000LL + configStat.st_mtim.tv_nsec;
        regionEnabled = true;
    }

    signal(SIGINT, on_signal); signal(SIGTERM, on_signal); signal(SIGHUP, on_signal);
    int phys = open(dev, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
    if (phys < 0) { perror("open physical input"); return 4; }

    std::vector<unsigned long> evbits((EV_MAX + sizeof(long)*8)/(sizeof(long)*8), 0);
    if (ioctl(phys, EVIOCGBIT(0, evbits.size()*sizeof(long)), evbits.data()) < 0) {
        perror("EVIOCGBIT"); close(phys); return 5;
    }
    int virt = open("/dev/uinput", O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (virt < 0) { perror("open /dev/uinput"); close(phys); return 6; }

    // Preserve direct-touch properties so Android InputReader can classify the
    // virtual device as a touchscreen rather than a generic pointer.
    std::vector<unsigned long> propbits((INPUT_PROP_MAX + sizeof(long)*8)/(sizeof(long)*8), 0);
    if (ioctl(phys, EVIOCGPROP(propbits.size()*sizeof(long)), propbits.data()) == 0) {
        for (int p=0; p<=INPUT_PROP_MAX; ++p) if (bit(propbits,p))
            ioctl(virt, UI_SET_PROPBIT, p);
    }

    // Clone supported event types and codes. Ignore unsupported ioctl codes.
    for (int t=0; t<=EV_MAX; ++t) if (bit(evbits,t)) {
        if (!setbit(virt, UI_SET_EVBIT, t)) { perror("UI_SET_EVBIT"); cleanup(phys,virt); return 7; }
        if (t == EV_KEY || t == EV_ABS || t == EV_REL || t == EV_MSC || t == EV_SW) {
            int maxcode = (t==EV_KEY ? KEY_MAX : t==EV_ABS ? ABS_MAX : t==EV_REL ? REL_MAX : t==EV_MSC ? MSC_MAX : SW_MAX);
            std::vector<unsigned long> codes((maxcode + sizeof(long)*8)/(sizeof(long)*8),0);
            if (ioctl(phys, EVIOCGBIT(t,codes.size()*sizeof(long)),codes.data()) == 0) {
                for (int c=0;c<=maxcode;++c) if (bit(codes,c)) {
                    unsigned long req = t==EV_KEY ? UI_SET_KEYBIT : t==EV_ABS ? UI_SET_ABSBIT :
                                        t==EV_REL ? UI_SET_RELBIT : t==EV_MSC ? UI_SET_MSCBIT : UI_SET_SWBIT;
                    setbit(virt,req,c);
                    if (t==EV_ABS) {
                        input_absinfo a{};
                        if (ioctl(phys,EVIOCGABS(c),&a)==0) {
                            uinput_abs_setup as{}; as.code=c; as.absinfo=a;
                            ioctl(virt,UI_ABS_SETUP,&as);
                        }
                    }
                }
            }
        }
    }

    uinput_setup setup{};
    input_id physical_id{};
    char physical_name[256]{};
    ioctl(phys, EVIOCGID, &physical_id);
    ioctl(phys, EVIOCGNAME(sizeof(physical_name)), physical_name);
    setup.id.bustype = BUS_VIRTUAL;
    setup.id.vendor = physical_id.vendor;
    setup.id.product = physical_id.product;
    setup.id.version = physical_id.version;
    snprintf(setup.name,sizeof(setup.name),"TouchAssist %.66s", physical_name[0] ? physical_name : "virtual touchscreen");
    if (ioctl(virt,UI_DEV_SETUP,&setup)<0 || ioctl(virt,UI_DEV_CREATE)<0) {
        perror("create virtual input"); cleanup(phys,virt); return 8;
    }
    usleep(250000); // allow Android InputReader to discover the virtual device

    // Re-check watchdog immediately before taking exclusive ownership.
    if (!fresh(heartbeat,watchdog)) {
        fprintf(stderr,"heartbeat expired before grab; aborting\n"); cleanup(phys,virt); return 9;
    }
    if (ioctl(phys,EVIOCGRAB,1)<0) {
        perror("EVIOCGRAB (exclusive grab unavailable)"); cleanup(phys,virt); return 10;
    }

    fprintf(stderr,"GRABBED %s -> virtual uinput; watchdog=%ds; region-engine=%s\n",dev,watchdog,regionEnabled?"enabled":"passthrough");
    input_event ev{};
    long long last_check=0;
    while (!g_stop) {
        if (now_ms()-last_check >= 250) {
            last_check=now_ms();
            if (!fresh(heartbeat,watchdog)) {
                fprintf(stderr,"watchdog expired; releasing physical touchscreen\n");
                break;
            }
            if (regionEnabled && regionConfigPath) {
                struct stat cs{};
                const long long configStamp = (stat(regionConfigPath, &cs) == 0)
                    ? static_cast<long long>(cs.st_mtim.tv_sec) * 1000000000LL + cs.st_mtim.tv_nsec : regionConfigMtime;
                if (configStamp != regionConfigMtime) {
                    ta::RuntimeConfig updated{};
                    if (ta::loadRuntimeConfig(regionConfigPath, updated)) {
                        regionRuntime->replaceConfig(std::move(updated));
                        regionConfigMtime = configStamp;
                        fprintf(stderr, "region configuration reloaded\n");
                    }
                }
            }
        }
        // poll() keeps the watchdog responsive even when the user is not touching
        // the screen. A blocking read here could otherwise hold EVIOCGRAB forever.
        pollfd pfd{}; pfd.fd=phys; pfd.events=POLLIN | POLLERR | POLLHUP;
        int pr=poll(&pfd,1,100);
        if (pr<0) {
            if (errno==EINTR) continue;
            fprintf(stderr,"poll failed; releasing grab: %s\n",strerror(errno));
            break;
        }
        if (pr==0) continue;
        if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) {
            fprintf(stderr,"physical input poll error; releasing grab\n");
            break;
        }
        if (pfd.revents & POLLIN) {
            ssize_t n=read(phys,&ev,sizeof(ev));
            if (n==(ssize_t)sizeof(ev)) {
                if (regionEnabled) {
                    // Retiming must see the previous contact state on release;
                    // consume() clears the slot when TRACKING_ID becomes -1.
                    regionRuntime->retime(ev);
                    (void)regionRuntime->consume(ev);
                }
                ssize_t w=write(virt,&ev,sizeof(ev));
                if (w!=(ssize_t)sizeof(ev)) {
                    fprintf(stderr,"virtual write failed; releasing grab: %s\n",strerror(errno));
                    break;
                }
            } else if (n<0 && (errno==EINTR || errno==EAGAIN || errno==EWOULDBLOCK)) continue;
            else {
                fprintf(stderr,"physical read failed; releasing grab: %s\n",n<0?strerror(errno):"short event");
                break;
            }
        }
    }
    cleanup(phys,virt);
    fprintf(stderr,"released; physical touchscreen is available again\n");
    return 0;
}
