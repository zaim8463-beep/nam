TouchAssist region status
=========================

The app stores regions separately from gestures and offers region-specific
settings. The current app still executes saved region strokes through the
AccessibilityService; it does not yet intercept physical touchscreen events.

The native/touchbridge directory contains a separate experimental raw-event
passthrough. It is not connected to the Android app and does not yet read saved
region geometry or apply region settings. See native/touchbridge/README.md.

This package is a development prototype, not a final APK or a finished raw-touch
region engine. No Android NDK build or OPPO-device runtime test has been done.
