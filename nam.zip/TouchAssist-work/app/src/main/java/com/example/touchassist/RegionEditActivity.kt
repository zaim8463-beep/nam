package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** إعدادات منطقة مستقلة، مع استخدام نفس المسارات التي يسجلها RecorderView للإيماءات. */
class RegionEditActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(0xFF333333.toInt())
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun field(value: String, decimal: Boolean = false) = EditText(this).apply {
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER or if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0
        setText(value)
    }

    private fun addField(root: LinearLayout, title: String, value: String, decimal: Boolean = false): EditText {
        root.addView(label(title))
        val e = field(value, decimal)
        root.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        return e
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val id = intent.getStringExtra("id")
        val isNew = id == null
        val region = if (id == null) AssistService.pendingRegion else Store.loadRegions(this).firstOrNull { it.gesture.id == id }
        if (region == null) { finish(); return }
        val g = region.gesture
        val settings = region.settings

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
        }
        root.addView(label(if (isNew) "اسم تحديد المنطقة" else "تعديل المنطقة"))
        val name = field(g.name)
        root.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))

        root.addView(label("طريقة تشغيل المنطقة"))
        val modes = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val ball = RadioButton(this).apply { id = 8101; text = "الطريقة الأولى: إظهار كرة عائمة أحركها وأثبتها" }
        val direct = RadioButton(this).apply { id = 8102; text = "الطريقة الثانية: تشغيل الخطوط مباشرة من دون كرة" }
        modes.addView(ball); modes.addView(direct)
        modes.check(if (region.floatingBall) 8101 else 8102)
        root.addView(modes)

        root.addView(label("طريقة تحديد الجزء المتأثر من المنطقة"))
        val hitModes = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val pathMode = RadioButton(this).apply { id = 8201; text = "الخطوط نفسها فقط: التأثير عند لمس المسارات المرسومة" }
        val enclosedMode = RadioButton(this).apply { id = 8202; text = "المساحة المحاطة: التأثير داخل حدود المنطقة" }
        val bothMode = RadioButton(this).apply { id = 8203; text = "الاثنان معاً: الخطوط والمساحة المحاطة" }
        hitModes.addView(pathMode); hitModes.addView(enclosedMode); hitModes.addView(bothMode)
        hitModes.check(when (region.hitMode) {
            RegionHitMode.PATHS -> 8201
            RegionHitMode.ENCLOSED -> 8202
            RegionHitMode.BOTH -> 8203
        })
        root.addView(hitModes)

        root.addView(label("إعدادات المنطقة — المدد بالمللي ثانية من 0 إلى 1000"))
        val touchDuration = addField(root, "مدة اللمس (0–1000 مللي ثانية)", settings.touchDurationMs.toString())
        val touchSpeed = addField(root, "سرعة اللمس (معامل 0.1 إلى 10)", settings.touchSpeed.toString(), true)
        val swipeDuration = addField(root, "مدة السحب (0–1000 مللي ثانية)", settings.swipeDurationMs.toString())
        val swipeSpeed = addField(root, "سرعة السحب (معامل 0.1 إلى 10)", settings.swipeSpeed.toString(), true)
        val tapDuration = addField(root, "مدة النقر (0–1000 مللي ثانية)", settings.tapDurationMs.toString())
        val longDuration = addField(root, "مدة الضغط المطوّل (0–1000 مللي ثانية)", settings.longPressDurationMs.toString())

        root.addView(label("عدد الخطوط المسجلة: ${g.strokes.size} • زمن التسجيل: ${g.totalDuration} مللي ثانية"))
        root.addView(label("الإعدادات دي محفوظة للمنطقة وحدها ولا تغيّر إعدادات الإيماءات. تنبيه: تطبيق التأثير على اللمس الحقيقي يتطلب محرك Root؛ الواجهة والحفظ لا يعنيان أن اعتراض اللمس مفعّل."))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                g.name = name.text.toString().trim().ifEmpty { "منطقة جديدة" }
                region.floatingBall = modes.checkedRadioButtonId == 8101
                region.hitMode = when (hitModes.checkedRadioButtonId) {
                    8201 -> RegionHitMode.PATHS
                    8202 -> RegionHitMode.ENCLOSED
                    else -> RegionHitMode.BOTH
                }
                settings.touchDurationMs = touchDuration.text.toString().toIntOrNull() ?: 100
                settings.touchSpeed = touchSpeed.text.toString().toFloatOrNull() ?: 1f
                settings.swipeDurationMs = swipeDuration.text.toString().toIntOrNull() ?: 150
                settings.swipeSpeed = swipeSpeed.text.toString().toFloatOrNull() ?: 1f
                settings.tapDurationMs = tapDuration.text.toString().toIntOrNull() ?: 100
                settings.longPressDurationMs = longDuration.text.toString().toIntOrNull() ?: 500
                settings.normalize()
                Store.upsertRegion(this@RegionEditActivity, region)
                if (isNew) AssistService.pendingRegion = null
                Toast.makeText(this@RegionEditActivity, "تم حفظ المنطقة: ${g.name}", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        buttons.addView(save, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (!isNew) {
            val delete = Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    AlertDialog.Builder(this@RegionEditActivity)
                        .setMessage("حذف المنطقة «${g.name}»؟")
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("حذف") { _, _ ->
                            Store.deleteRegion(this@RegionEditActivity, g.id)
                            finish()
                        }.show()
                }
            }
            buttons.addView(delete, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(buttons)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
}
