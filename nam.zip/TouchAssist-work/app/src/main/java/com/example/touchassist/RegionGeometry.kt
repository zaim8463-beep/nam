package com.example.touchassist

import kotlin.math.max
import kotlin.math.sqrt

/** هندسة المنطقة على إحداثيات الشاشة. الإزاحة تمثل نقل المنطقة عند تثبيت الكرة. */
object RegionGeometry {
    data class Transform(
        val screenWidth: Int,
        val screenHeight: Int,
        val offsetX: Float = 0f,
        val offsetY: Float = 0f
    )

    /**
     * يفحص هل النقطة ضمن الجزء المحدد من المنطقة.
     * PATHS: قرب أي خط مرسوم. ENCLOSED: داخل المضلع المغلق. BOTH: أحدهما.
     * tolerancePx نصف قطر السماحية حول الخطوط.
     */
    fun contains(
        region: TouchRegion,
        x: Float,
        y: Float,
        transform: Transform,
        tolerancePx: Float = 18f
    ): Boolean {
        val g = region.gesture
        if (g.screenW <= 0 || g.screenH <= 0 || transform.screenWidth <= 0 || transform.screenHeight <= 0) return false
        val sx = transform.screenWidth.toFloat() / g.screenW
        val sy = transform.screenHeight.toFloat() / g.screenH
        val paths = g.strokes.map { stroke ->
            stroke.points.map { p ->
                Pair(p.x * sx + transform.offsetX, p.y * sy + transform.offsetY)
            }
        }.filter { it.isNotEmpty() }
        val onPath = paths.any { pts ->
            if (pts.size == 1) distance(x, y, pts[0].first, pts[0].second) <= tolerancePx
            else pts.zipWithNext().any { (a, b) -> pointSegmentDistance(x, y, a.first, a.second, b.first, b.second) <= tolerancePx }
        }
        // Each recorded stroke is an independent contour. Never concatenate
        // separate strokes into one polygon: doing so invents edges between
        // unrelated paths and can mark large, unintended areas as active.
        val enclosed = paths.any { pts ->
            pts.size >= 4 && isClosedContour(pts, tolerancePx) &&
                pointInPolygon(x, y, pts.dropLast(1))
        }
        return when (region.hitMode) {
            RegionHitMode.PATHS -> onPath
            RegionHitMode.ENCLOSED -> enclosed
            RegionHitMode.BOTH -> onPath || enclosed
        }
    }

    private fun isClosedContour(points: List<Pair<Float, Float>>, tolerancePx: Float): Boolean {
        val first = points.first()
        val last = points.last()
        return distance(first.first, first.second, last.first, last.second) <= tolerancePx
    }

    private fun pointInPolygon(x: Float, y: Float, points: List<Pair<Float, Float>>): Boolean {
        var inside = false
        var j = points.lastIndex
        for (i in points.indices) {
            val a = points[i]
            val b = points[j]
            if (pointSegmentDistance(x, y, a.first, a.second, b.first, b.second) <= 0.5f) return true
            val crosses = (a.second > y) != (b.second > y) &&
                x < (b.first - a.first) * (y - a.second) / (b.second - a.second) + a.first
            if (crosses) inside = !inside
            j = i
        }
        return inside
    }

    private fun pointSegmentDistance(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val len2 = dx * dx + dy * dy
        if (len2 <= 0.0001f) return distance(px, py, ax, ay)
        val t = (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0f, 1f)
        return distance(px, py, ax + t * dx, ay + t * dy)
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2
        val dy = y1 - y2
        return sqrt(max(0f, dx * dx + dy * dy))
    }
}
