#!/system/bin/sh
# Root supervisor. Its heartbeat expires automatically if the app process dies.
set -eu
DEV="${1:-/dev/input/event3}"
APP_PID="${2:-}"
BIN="${3:-}"
REGION_CONF="${4:-}"
HB="/data/local/tmp/touchassist_touchbridge.hb"
LOG="/data/local/tmp/touchassist_touchbridge.log"
SUP_PID_FILE="/data/local/tmp/touchassist_touchbridge.supervisor.pid"
READY="/data/local/tmp/touchassist_touchbridge.ready"
BRIDGE_PID=""

[ -n "$APP_PID" ] && [ -n "$BIN" ] && [ -n "$REGION_CONF" ] || exit 2
[ -c "$DEV" ] || { echo "Not a character input device: $DEV" >>"$LOG"; exit 3; }
[ -x "$BIN" ] || { echo "Missing executable: $BIN" >>"$LOG"; exit 4; }
[ -r "$REGION_CONF" ] || { echo "Missing region config: $REGION_CONF" >>"$LOG"; exit 7; }
kill -0 "$APP_PID" 2>/dev/null || exit 5
if [ -s "$SUP_PID_FILE" ]; then
  OLD="$(cat "$SUP_PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD" ] && kill -0 "$OLD" 2>/dev/null; then
    echo "Supervisor already running: $OLD" >>"$LOG"; exit 6
  fi
  rm -f "$SUP_PID_FILE"
fi
if pidof touchbridge >/dev/null 2>&1; then
  echo "A touchbridge process already exists; refusing a second grab" >>"$LOG"; exit 6
fi

echo $$ > "$SUP_PID_FILE"
cleanup() {
  rm -f "$READY"
  if [ -n "$BRIDGE_PID" ]; then
    kill -TERM "$BRIDGE_PID" 2>/dev/null || true
    wait "$BRIDGE_PID" 2>/dev/null || true
    BRIDGE_PID=""
  fi
  rm -f "$HB" "$SUP_PID_FILE"
}
trap cleanup EXIT INT TERM HUP
: > "$HB"
"$BIN" "$DEV" "$HB" 5 "$REGION_CONF" >>"$LOG" 2>&1 &
BRIDGE_PID=$!
# Do not report startup success merely because the supervisor PID file exists.
sleep 1
if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then
  wait "$BRIDGE_PID" || STATUS=$?
  echo "touchbridge failed during startup (status ${STATUS:-unknown})" >>"$LOG"
  exit 8
fi
# Signal readiness only after the native process survived its startup window.
echo "$BRIDGE_PID" > "$READY"
while kill -0 "$APP_PID" 2>/dev/null && kill -0 "$BRIDGE_PID" 2>/dev/null; do
  touch "$HB"
  sleep 1
done
cleanup
trap - EXIT INT TERM HUP
echo "TouchAssist bridge stopped; physical input release requested" >>"$LOG"
