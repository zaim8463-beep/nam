#!/system/bin/sh
set -u
PID_FILE="/data/local/tmp/touchassist_touchbridge.supervisor.pid"
HB="/data/local/tmp/touchassist_touchbridge.hb"
READY="/data/local/tmp/touchassist_touchbridge.ready"
if [ -s "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  case "$PID" in
    ''|*[!0-9]*) ;;
    *)
      kill -TERM "$PID" 2>/dev/null || true
      i=0
      while [ "$i" -lt 6 ] && kill -0 "$PID" 2>/dev/null; do
        sleep 1
        i=$((i+1))
      done
      # The heartbeat removal is the independent fallback if signaling failed.
      rm -f "$HB"
      ;;
  esac
fi
rm -f "$HB" "$READY"
exit 0
